#include <iostream>
#include <fstream>
#include <string>
#include <unordered_map>

using namespace std;

class ItemTracker { //Item Tracking Functionality 
private:
    unordered_map<string, int> itemFrequency;  // Store item frequencies in an unordered map

public:
    void load_data_from_file(const string& filename) { //Reads data from file and updates the itemFrequency map 
        ifstream file(filename); //Opens the Files
        string item;
        while (getline(file, item)) { // Reads each line
            update_frequency(item);  // Updating the item frequencies
        }
        file.close();
    }

    void update_frequency(const string& item) {
        itemFrequency[item]++;  // Increment the frequency of the item
    }

    int get_item_frequency(const string& item) {
        return itemFrequency[item];  // Retrieve the frequency of the item
    }

    void print_item_frequency() {
        for (const auto& pair : itemFrequency) {
            cout << pair.first << ": " << pair.second << endl;  // Print item frequencies
        }
    }

    void print_histogram() {
        for (const auto& pair : itemFrequency) {
            cout << pair.first << " ";
            for (int i = 0; i < pair.second; i++) {
                cout << "*";  // Print item histogram using asterisks
            }
            cout << endl;
        }
    }

    void backup_data_to_file(const string& filename) {
        ofstream file(filename);
        for (const auto& pair : itemFrequency) {
            file << pair.first << ":" << pair.second << endl;  // Backup item frequencies to a file
        }
        file.close();
    }
};

int main() {
    ItemTracker itemTracker;
    itemTracker.load_data_from_file("CS210_Project_Three_Input_File.txt");  // Load data from input file

    while (true) {
        cout << "Menu:" << endl;
        cout << "1. Search for an item" << endl;
        cout << "2. Print item frequencies" << endl;
        cout << "3. Print item histogram" << endl;
        cout << "4. Exit" << endl;

        int choice;
        cout << "Enter your choice: ";
        cin >> choice;

        if (choice == 1) {
            string item;
            cout << "Enter the item to search for: ";
            cin.ignore();
            getline(cin, item);
            int frequency = itemTracker.get_item_frequency(item);
            cout << "The item '" << item << "' was purchased " << frequency << " time(s)." << endl;  // Search for an item and display its frequency
        }
        else if (choice == 2) {
            itemTracker.print_item_frequency();  // Print item frequencies
        }
        else if (choice == 3) {
            itemTracker.print_histogram();  // Print item histogram
        }
        else if (choice == 4) {
            itemTracker.backup_data_to_file("frequency.dat");  // Backup data to a file
            cout << "Data backup saved to 'frequency.dat'. Exiting..." << endl;
            break;
        }
        else {
            cout << "Invalid choice. Please try again." << endl;  // Handle invalid menu choices
        }
    }

    return 0;
}
